package com.example.cible

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
