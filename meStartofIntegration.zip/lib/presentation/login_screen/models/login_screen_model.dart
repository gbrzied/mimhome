// ignore_for_file: must_be_immutable
class LoginScreenModel {
  LoginScreenModel({
    this.phoneNumberController,
    this.errorMessage,
  });

  String? phoneNumberController;

  String? errorMessage;
}